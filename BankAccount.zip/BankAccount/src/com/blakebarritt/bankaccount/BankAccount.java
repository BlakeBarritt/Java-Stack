package com.blakebarritt.bankaccount;
import java.util.Random;

public class BankAccount {
//	Member Variables
	private String accountNumber;
	private double checkingBalance;
	private double savingsBalance;

// Class Variables
	public static int numberOfAccounts;
	public static double totalAmount;
	
// Constructors
	//	Empty
	public BankAccount() {
//		Static variables need to be in all constructors
		numberOfAccounts++;
		
	}
	
	// Full
	public BankAccount(double checkingBalance, double savingsBalance) {
		super();
		this.accountNumber = accountNumberGenerator();
		this.checkingBalance = checkingBalance;
		this.savingsBalance = savingsBalance;
		accountNumberGenerator();
		numberOfAccounts++;
	}

// Getters and Setters
	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getCheckingBalance() {
		return checkingBalance;
	}

	public void setCheckingBalance(double checkingBalance) {
		this.checkingBalance = checkingBalance;
	}

	public double getSavingsBalance() {
		return savingsBalance;
	}

	public void setSavingsBalance(double savingsBalance) {
		this.savingsBalance = savingsBalance;
	}
	
// Other Methods
	private String accountNumberGenerator() {
		Random generator = new Random();
		String accountNumber = "";
		for (int i = 0; i < 10; i++) {
			int num = generator.nextInt(10);
			accountNumber += num;
		}
		return accountNumber;
	}
	
	public void deposit(String accountType, double amount) {
		if (accountType.equals("checking")) {
			System.out.println("Checking account being deposited");
			this.checkingBalance += amount;
			totalAmount += amount;
		}
		else if (accountType.equals("savings"))  {
			System.out.println("Savings account being deposited");
			this.savingsBalance += amount;
			totalAmount += amount;
		}
	}
	
	public void withdrawal(String accountType, double amount) {
		if (accountType.equals("checking")) {
			if (this.checkingBalance < amount) {
				System.out.println("Insufficient funds");
			}
			else {System.out.println("Checking account being withdrawn");
			this.checkingBalance -= amount;
			totalAmount -= amount;
			}
		}
		if (accountType.equals("savings")) {
			if (this.savingsBalance < amount) {
				System.out.println("Insufficient funds");
			}
			else {System.out.println("Checking account being withdrawn");
			this.checkingBalance -= amount;
			totalAmount -= amount;
			}
		}
	}
	
}
