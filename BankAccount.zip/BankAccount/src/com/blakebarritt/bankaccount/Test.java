package com.blakebarritt.bankaccount;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BankAccount account1 = new BankAccount(200.00, 200.00);
		BankAccount account2 = new BankAccount(100.00, 90.00);
		
		System.out.println(account1.getAccountNumber());
		System.out.println(account2.getAccountNumber());
		
		System.out.println(BankAccount.numberOfAccounts);
		
		System.out.println(account1.getCheckingBalance());
		account1.deposit("checking", 50.00);
		System.out.println(account1.getCheckingBalance());
		account1.withdrawal("savings", 300.00);
		
	}

}
