package com.blakebarritt.controllerviews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControllerAndViewsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControllerAndViewsApplication.class, args);
	}

}
