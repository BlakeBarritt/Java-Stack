package com.blakebarritt.controllerviews.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.blakebarritt.controllerviews.models.User;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {
//	Need this on registration to prevent duplicate emails
    User findByEmail(String email);
}