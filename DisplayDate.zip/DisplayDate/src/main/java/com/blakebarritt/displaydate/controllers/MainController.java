package com.blakebarritt.displaydate.controllers;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller

public class MainController {
	@RequestMapping("")
	public String home() {
		return "index.jsp";
	}
	
	@RequestMapping("/date")
	public String date(Model model) {
//		Get Data
		SimpleDateFormat dateFormatter = new SimpleDateFormat("EEEEE, dd MMMMM, yyyy");
		String date = dateFormatter.format(new Date());
//		Pass data to JSP file
		model.addAttribute("date", date);
		return "date.jsp";
	}
	
	@RequestMapping("/time")
	public String time(Model model) {
//		Get Data
		SimpleDateFormat timeFormatter = new SimpleDateFormat("hh:mm a");
		String time = timeFormatter.format(new Date());
//		Pass data to JSP file
		model.addAttribute("time", time);
		return "time.jsp";
	}
}
