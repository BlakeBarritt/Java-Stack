package com.blakebarritt.dojosandninjas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DojosAndNinjasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DojosAndNinjasApplication.class, args);
	}

}
