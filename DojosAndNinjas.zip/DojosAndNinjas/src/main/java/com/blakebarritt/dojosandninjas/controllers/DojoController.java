package com.blakebarritt.dojosandninjas.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.blakebarritt.dojosandninjas.models.Dojo;
import com.blakebarritt.dojosandninjas.services.MainService;

@Controller
public class DojoController {
	@Autowired
	private MainService mainServ;
	
	//Constructor
	public DojoController(MainService mainServ) {
		this.mainServ = mainServ;
	}
	
	@GetMapping("/dojos/new")
	public String index(
		@ModelAttribute("dojoObj")Dojo emptyDojo, Model model) {
		model.addAttribute("allDojos", mainServ.getAllDojos());
		return "index.jsp";
	}
	@PostMapping("/dojos/add")
	public String createDojo(
		@Valid @ModelAttribute("dojoObj") Dojo filledDojo, BindingResult results, Model model
		) {
			if(results.hasErrors()) {
				model.addAttribute("allDojos", mainServ.getAllDojos());
				return "index.jsp";
			}
			else {
				mainServ.createDojo(filledDojo);
				return "redirect:/dojos/new";
			}
	}
//	Table
	@GetMapping("/dojos/{id}")
	public String display(
		@PathVariable("id") Long id, Model model) {
		Dojo dojo = mainServ.getDojo(id);
		model.addAttribute("dojo", dojo);
		return "dojos.jsp";
	}
	
}
