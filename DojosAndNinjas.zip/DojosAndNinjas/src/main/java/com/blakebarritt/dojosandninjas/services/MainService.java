package com.blakebarritt.dojosandninjas.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.blakebarritt.dojosandninjas.models.Dojo;
import com.blakebarritt.dojosandninjas.models.Ninja;
import com.blakebarritt.dojosandninjas.repositories.DojoRepository;
import com.blakebarritt.dojosandninjas.repositories.NinjaRepository;

@Service
public class MainService {
// Bring in both repositories //
	public final DojoRepository dojoRepo;
	public final NinjaRepository ninjaRepo;
// Constructor //
	public MainService(DojoRepository dojoRepo, NinjaRepository ninjaRepo) {
		//	Don't need super
	this.dojoRepo = dojoRepo;
	this.ninjaRepo = ninjaRepo;
	}
	
//	CRUD Operations for Dojo //
	
	// Create
	public Dojo createDojo(Dojo newDojo) {
		return dojoRepo.save(newDojo);
	}
	
	// Read (one and all)
	public Dojo getDojo(Long id) {
		return dojoRepo.findById(id).orElse(null);
	}
	
	public List<Dojo> getAllDojos(){
		return dojoRepo.findAll();
	}
	
	
	
	
//	CRUD Operations for Ninja //
	
	// Create
	public Ninja createNinja(Ninja newNinja) {
		return ninjaRepo.save(newNinja);
	}
	// Read (one and all)
	public Ninja getNinja(Long id) {
		return ninjaRepo.findById(id).orElse(null);
	}
		
	public List<Ninja> getAllNinjas(){
		return ninjaRepo.findAll();
	}
		
	
}
