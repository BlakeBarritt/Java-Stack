package com.blakebarritt.gettingfamiliarwithrouting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GettingFamiliarWithRoutingApplicationTests {

	@Test
	void contextLoads() {
	}

}
