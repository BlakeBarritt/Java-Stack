package com.blakebarritt.languages;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Languages1Application {

	public static void main(String[] args) {
		SpringApplication.run(Languages1Application.class, args);
	}

}
