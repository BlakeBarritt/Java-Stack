package com.blakebarritt.languages.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.blakebarritt.languages.models.Languages;
import com.blakebarritt.languages.services.LanguagesService;

@Controller
public class MainController {
	@Autowired
	private LanguagesService languageService;
//	----------------------------- Create ------------------------------- //
	@GetMapping("/languages")
	public String index(
		@ModelAttribute("languagesObj")Languages emptyLanguage, Model model) {
		model.addAttribute("allLanguages", languageService.allLanguages());
		return "index.jsp";
	}
	
	@PostMapping("/languages/new")
	public String createLanguage(
		@Valid @ModelAttribute("languagesObj") Languages filledLanguage, BindingResult results, Model model
		) {
			if(results.hasErrors()) {
				model.addAttribute("allLanguages", languageService.allLanguages());
				return "index.jsp";
			}
			else {
				languageService.saveLanguage(filledLanguage);
				return "redirect:/languages";
			}
	}
	
//	----------------------------- Read ------------------------------- //
	@GetMapping("languages/{id}")
	public String language(
			@PathVariable("id") Long id, Model model
			) {
				Languages oneLanguage = languageService.findLanguage(id);
				model.addAttribute("oneLanguage", oneLanguage);
				return "language.jsp";
	}
	
//	---------------------------- Update ------------------------------ //
	@GetMapping("/languages/{id}/edit")
	public String editLanguage(
		@PathVariable("id") Long id, Model model
		) {
		Languages editLanguage = languageService.findLanguage(id);
		model.addAttribute("languagesObj", editLanguage);
		return "edit.jsp";
	}
	
	@PutMapping("/languages/{id}/edit")
	public String update(
		@Valid @ModelAttribute("languagesObj") Languages filledLanguage, BindingResult results, Model model,
		@PathVariable("id") Long id
		) {
			if(results.hasErrors()) {
				return "edit.jsp";
			}
			else {
				languageService.saveLanguage(filledLanguage);
				return "redirect:/languages/" + id;
			}
	}
	
//	---------------------------- Delete ------------------------------ //
	@GetMapping("/languages/{id}/delete")
	public String delete(
		@PathVariable("id") Long id
		) {
			languageService.deleteLanguage(id);
			return "redirect:/languages";
	}
}
