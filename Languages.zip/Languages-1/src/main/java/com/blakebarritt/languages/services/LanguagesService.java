package com.blakebarritt.languages.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blakebarritt.languages.models.Languages;
import com.blakebarritt.languages.repositories.LanguagesRepository;

@Service
public class LanguagesService {
	@Autowired
	private final LanguagesRepository languagesRepository;
	
	public LanguagesService(LanguagesRepository languagesRepository) {
		this.languagesRepository = languagesRepository;	
	}
	
	public Languages saveLanguage(Languages language) {
		return languagesRepository.save(language);
	}
	
	
	public List<Languages> allLanguages() {
		return languagesRepository.findAll();
	}
	
    public Languages findLanguage(Long id) {
        Optional<Languages> optionalLanguage = languagesRepository.findById(id);
        if(optionalLanguage.isPresent()) {
            return optionalLanguage.get();
        }
        else {
            return null;
        }
    }
    
    public Languages addLanguage(Languages l) {
    	return languagesRepository.save(l);
    }
    
    public void deleteLanguage(Long id) {
    	languagesRepository.deleteById(id);
    }
}