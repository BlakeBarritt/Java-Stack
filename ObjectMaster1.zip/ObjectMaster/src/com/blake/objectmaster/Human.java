package com.blake.objectmaster;

public class Human {
	
//////////////////	Member Variables //////////////////
	protected int strength;
	protected int intelligence;
	protected int stealth;
	protected int health;
	
////////////////// Constructors //////////////////
	public Human() {
		this.strength = 3;
		this.intelligence = 3;
		this.stealth = 3;
		this.health = 100;
	}

//////////////////	Getters and Setters //////////////////
	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}

	public int getIntelligence() {
		return intelligence;
	}

	public void setIntelligence(int intelligence) {
		this.intelligence = intelligence;
	}

	public int getStealth() {
		return stealth;
	}

	public void setStealth(int stealth) {
		this.stealth = stealth;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}
	
////////////////// Other Methods //////////////////
	public int displayHealth() {
		System.out.println(this.health);
		return this.health;
	}
	
	public void attack(Human enemy) {
		enemy.health -= this.strength;
		System.out.println("Your enemy's health is now " + enemy.health);
	}


	
	
}
