package com.blake.test;

import com.blake.objectmaster.*;

public class Test {

	public static void main(String[] args) {
		Human blake = new Human ();
		Human jim = new Human();
		
		blake.attack(jim);

	}

}
