package com.blake.objectmaster;

public class Ninja extends Human {

	public Ninja() {
		super();
		this.stealth = 10;
	}
	
	public void steal(Human target) {
		target.health -= this.stealth;
		this.health += this.stealth;
		System.out.println("Your target was damaged to " + target.health);
		System.out.println("Ninja was healed to " + this.health);
	}

	public void runaway() {
		this.health -= 10;
		System.out.println("Po ran and now as a health of " + this.health);
	}
}
