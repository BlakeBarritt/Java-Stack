package com.blake.objectmaster;

public class Samurai extends Human {
//	initialize static variable (belongs to class) 
//	so we can have a counter for samurai
	private static int samuraiCount = 0;
	
	public Samurai() {
		super();
		this.health = 200;
	}

	public void deathBlow(Human target) {
		target.health = 0;
		this.health *= .5;
		System.out.println("You dealt the target a death blow ");
		System.out.println("Samurai's health is now half: " + this.health);
	}
	
	public void meditate() {
		this.health = 2 * this.health;
		System.out.println("Samurai's has healed: " + this.health);
	}
	
	public int howMany() {
		System.out.println(samuraiCount);
		return samuraiCount;
	}
}
