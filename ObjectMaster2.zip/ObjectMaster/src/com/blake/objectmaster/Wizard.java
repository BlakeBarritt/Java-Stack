package com.blake.objectmaster;

public class Wizard extends Human {

	public Wizard() {
		super();
		this.health = 50;
		this.intelligence = 8;
	}
	
	public void heal(Human target) {
		target.health += this.intelligence;
		System.out.println("Your target was healed to " + target.health);
	}
	
	public void fireball(Human target) {
		target.health -= 3 * this.intelligence;
		System.out.println("Your target was damaged to " + target.health);
	}


	

}
