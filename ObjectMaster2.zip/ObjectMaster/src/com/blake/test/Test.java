package com.blake.test;

import com.blake.objectmaster.*;

public class Test {

	public static void main(String[] args) {
		Human blake = new Human ();
		Human jim = new Human();
		
		blake.attack(jim);

		Wizard wiz = new Wizard();
		wiz.heal(jim);
		
		wiz.fireball(jim);
		
		Ninja Po = new Ninja();
		Po.steal(jim);
		Po.runaway();

		Samurai Nobunaga = new Samurai();
		Nobunaga.deathBlow(jim);
		Nobunaga.meditate();
		
		Nobunaga.howMany();
	}

}
