package com.blake.zoo;

public class Gorilla extends Mammal {
	public Gorilla() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Gorilla(int energyLevel) {
		super(energyLevel);
		// TODO Auto-generated constructor stub
	}
	
	public void throwSomething() {
		this.energyLevel -=5;
		System.out.println("The gorilla has thrown something");
	}
	
	public void eatBananas() {
		this.energyLevel +=10;
		System.out.println("The gorilla ate bananas");
	}
	
	public void climb() {
		this.energyLevel -=10;
		System.out.println("The gorilla climbed a tree");
	}
}
