package com.blake.zoo;

public class Mammal {
	
//	Member Variables
	protected int energyLevel;
	
//	Constructors
	public Mammal() {
		this.energyLevel = 100;
	}
	
	public Mammal(int energyLevel) {
		this.energyLevel = energyLevel;
	}
	
// Getters and Setters
	public int getEnergy() {
		return energyLevel;
	}

	public void setEnergy(int energyLevel) {
		if (energyLevel >= 0) {
			this.energyLevel = energyLevel;
			}
	}

// Other
	public int displayEnergy() {
		System.out.println(this.energyLevel);
		return this.energyLevel;
	}
	
	
}
