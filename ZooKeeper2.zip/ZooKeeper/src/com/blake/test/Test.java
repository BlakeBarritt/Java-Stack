package com.blake.test;

import com.blake.zoo.*;

public class Test {

	public static void main(String[] args) {
		Gorilla Blake = new Gorilla ();
//		Blake.throwSomething();
//		Blake.throwSomething();
//		Blake.throwSomething();
//		Blake.eatBananas();
//		Blake.eatBananas();
//		Blake.eatBananas();
//		Blake.climb();
		Blake.displayEnergy();
		
		Bat Jim = new Bat ();
//		Jim.attackTown();
//		Jim.attackTown();
//		Jim.attackTown();
//		Jim.eatHumans();
//		Jim.eatHumans();
		Jim.fly();
		Jim.fly();
		Jim.displayEnergy();
	}

}
