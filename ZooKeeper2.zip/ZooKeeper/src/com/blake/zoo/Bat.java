package com.blake.zoo;

public class Bat extends Mammal {

	public Bat() {
		super(300);
////	Because we are passing an integer as an argument, 
//		Java will recognize and push to the 2nd constructor
//		in the main Mammal class, setting a new default bat energy
		
//		Could also override by:
//			super();
//			this.energyLevel = 300;
	}

	public Bat(int energyLevel) {
		super(energyLevel);

	}
	
	public void fly() {
		this.energyLevel -=50;
		System.out.println("The sound of a bat taking off");
	}
	
	public void eatHumans() {
		this.energyLevel +=25;
		System.out.println("Well... nevermind");
	}
	
	public void attackTown() {
		this.energyLevel -=100;
		System.out.println("The sound of a town on fire");
	}
	
}
